
from collections import deque

def bfs(capacity, source, sink, parent):
    visited = [False] * len(capacity)
    queue = deque([source])
    visited[source] = True

    while queue:
        u = queue.popleft()

        for v in range(len(capacity)):
            if not visited[v] and capacity[u][v] > 0:
                queue.append(v)
                visited[v] = True
                parent[v] = u
                if v == sink:
                    return True
    return False

def edmonds_karp(n, edges, source, sink):
    capacity = [[0] * n for _ in range(n)]
    for u, v, c in edges:
        capacity[u][v] = c

    parent = [-1] * n
    max_flow = 0

    while bfs(capacity, source, sink, parent):
        path_flow = float('Inf')
        s = sink

        while s != source:
            path_flow = min(path_flow, capacity[parent[s]][s])
            s = parent[s]

        v = sink
        while v != source:
            u = parent[v]
            capacity[u][v] -= path_flow
            capacity[v][u] += path_flow
            v = parent[v]

        max_flow += path_flow

    return max_flow

# Example 
n = 4
edges = [(0, 1, 100), (0, 2, 50), (1, 2, 50), (1, 3, 50), (2, 3, 100)]
source, sink = 0, 3
print(edmonds_karp(n, edges, source, sink))  # Output: 150
